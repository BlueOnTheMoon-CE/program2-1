"use strict"


//document ready
$(document).ready(function(){
    //tabs widget
    $("#tabs").tabs();

    console.log("document ready function:")



    //card amount
    cardAmount();

    //prelode card images
    //images array
    var imagesArray = [];
    function createImagesArray(){
        for(let i = 0; i < 24; i++){
            imagesArray[i] = ("images/card_" + (i + 1) +".png");
            console.log("imagesArray: " +imagesArray[i]);
        }
    }
    createImagesArray();

    //create card grid
    createCardGrid(imagesArray);
    
});


 //save settings (session storage)
document.getElementById("save_settings").onclick = function(){
        console.log("Settings saved")
    
    //Card amount
    let newCardAmount = document.getElementById("num_cards").value;
    document.getElementById("player").value = document.getElementById("player_name").value;
        console.log(newCardAmount + " and " + document.getElementById("player").value);
    sessionStorage.setItem("cardAmount", newCardAmount)

    //player name

    //high score
};


//manage cardAmount
function cardAmount(){
    let storedCardAmount = 0;
    if(sessionStorage.getItem("cardAmount") == null){
        sessionStorage.setItem("cardAmount", 48)
    }
    else{
        storedCardAmount = sessionStorage.getItem("cardAmount")
    }
    console.log("Starting card amount: " + storedCardAmount)
    document.getElementById("num_cards").value = storedCardAmount;
}


//create blank cards
function createCardGrid(imagesArray){
//<a src="" href="#"><img src="images/blank.png" alt=""></a>

    
    for(let i = 0; i < 48; i++){
        //img element
        let inImg = document.createElement("img");
        inImg.src = "images/back.png";
        inImg.id = "img" + (i +1);
        inImg.alt = "";

        //a element
        let outA = document.createElement("a")
        outA.src = "";
        outA.id = "a" + (i +1);
        outA.href = "#";

        //append a to cards
        document.getElementById("cards").appendChild(outA);
        console.log(outA.id)
        console.log(inImg.id)
        //append img to a
        document.getElementById("a"+(i+1)).appendChild(inImg);
    }

    //map image id to source array
    let randomArray = randomizeCards(imagesArray);
    let storeArray = []
    let cardAmount = sessionStorage.getItem("cardAmount")
    //fill store array
    for (let i = 0; i < cardAmount; i++) {
        storeArray[i] = {};
    }
    //run twice to create 2 identical cards with different IDs (places)
    for(let i = 0; i < (cardAmount/2); i++){
        //give it random image
        storeArray[i].src = randomArray[i]
        //give Id in order
        storeArray[i].id = "img" + (i + 1);
        console.log(storeArray[i].src)
    }
    randomArray = randomizeCards(randomArray); //re-randomize
    for(let i = 0; i < (cardAmount/2); i++){
        let adjusted = i+(cardAmount/2)
        //give it random image
        storeArray[adjusted].src = randomArray[i]
        //give Id in order
        storeArray[adjusted].id = "img" + (adjusted + 1);
        console.log(storeArray[adjusted].src)
    }


    //temporary IDs to compare click events
    var tempID1 = null;
    var tempID2 = null;
    
    //track amount of matches
    var scoreCounter = 0;

    //blank and back images to compare src
    var blank = new Image();
    var back = new Image();
    blank.src = "images/blank.png";
    back.src = "images/back.png";

    //keeps track of clicked cards
    let keeperArray = [];

    //assign click events
    for(let i = 0; i< 48; i++){
        //id for current assigning click events
        let imgId = "img" + (i + 1);

        document.getElementById(imgId).addEventListener("click", clickedOn(imgId, i));

    }

    //when clicked
    function clickedOn(clickID, index){
        //when clicked
        console.log("click event");
        //check if max clicked
        if(keeperArray.length < 2){
            //check if already clicked
            if(keeperArray.includes(document.getElementById(clickID))){
            }
            //if not clicked
            else{
                console.log("just clicked")

                //record the click
                keeperArray.push(clickID);

                //fade Out
                $("#" +clickID).fadeOut(500);
                //change src
                console.log(document.getElementById(clickID).src + " changed to: " + storeArray[index].src)
                document.getElementById(clickID).src = storeArray[index].src;
                //fade in
                $("#" +clickID).fadeIn(500);

                //check for amount of clicked cards
                if(keeperArray.length == 2){
                    tempID1 =keeperArray[0];
                    tempID2 = keeperArray[1];
                
                    //check if temp IDs match
                        if(tempID1.src == tempID2.src){
                            //make matched blank
                            document.getElementById(tempID1).src = "images/blank.png";
                            document.getElementById(tempID2).src = "images/blank.png";
                            //add to score
                            scoreCounter++;

                            //manage high score
                            if(sessionStorage.getItem("highScore") == null){
                                sessionStorage.setItem("highScore", scoreCounter)
                            }
                            else if(sessionStorage.getItem("highScore") < scoreCounter){
                                sessionStorage.setItem("highScore", scoreCounter)
                            }

                            //update score and high score
                            document.getElementById("correct").textContent = scoreCounter;
                            document.getElementById("high_score").textContent = sessionStorage.getItem("highScore");

                        }
                        else{
                            //make matched back
                            document.getElementById(tempID1).src = "images/back.png";
                            document.getElementById(tempID2).src = "images/back.png";
                        }
                    
                    //reset keeperArray
                    keeperArray = [];
                }
            }
        }
    }
}



//randomize
function randomizeCards(cardDeck){
    console.log("randomizeCards")
    for(let i = 0;  i < cardDeck.length; i++){
        let random = Math.floor(Math.random()*cardDeck.length);
        let store = cardDeck[random];
        cardDeck[random] = cardDeck[i];
        cardDeck[i] = store;
    }
    return cardDeck;
}

